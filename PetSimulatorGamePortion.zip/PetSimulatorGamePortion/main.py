import pygame
import os
from gym.spaces import Discrete, Box
import numpy as np
import sys
import math
import random
import gym

# import gym_game

pygame.font.init()
pygame.mixer.init()

WIDTH, HEIGHT = 900, 500
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pet Simulator")

BACKGROUND_IMAGE = pygame.image.load(os.path.join('Assets', 'background.jpg'))
# https://www.istockphoto.com/vector/animal-shelter-pet-shop-flat-vector-illustration-gm1164940889-320368026
BACKGROUND = pygame.transform.scale(BACKGROUND_IMAGE, (900, 500))

CAT1_IMAGE = pygame.image.load(os.path.join('Assets', 'cat1.png'))
CAT1 = pygame.transform.scale(CAT1_IMAGE, (200, 200))

CAT2_IMAGE = pygame.image.load(os.path.join('Assets', 'cat2.png'))
CAT3_IMAGE = pygame.image.load(os.path.join('Assets', 'cat3.png'))
CAT4_IMAGE = pygame.image.load(os.path.join('Assets', 'cat4.png'))
CAT5_IMAGE = pygame.image.load(os.path.join('Assets', 'cat5.png'))
DOG1_IMAGE = pygame.image.load(os.path.join('Assets', 'dog1.png'))
DOG1 = pygame.transform.scale(DOG1_IMAGE, (200, 200))

DOG2_IMAGE = pygame.image.load(os.path.join('Assets', 'dog2.png'))
DOG3_IMAGE = pygame.image.load(os.path.join('Assets', 'dog3.png'))
DOG4_IMAGE = pygame.image.load(os.path.join('Assets', 'dog4.png'))


class Dog():
    def __init__(self):
        self.dogSleep = random.randint(0, 33)
        self.dogEat = random.randint(0, 33)
        self.dogPlay = random.randint(0, 33)
        self.state = self.dogSleep + self.dogEat + self.dogPlay


class AnimalEnv(gym.Env):
    def __init__(self):
        # dog needs to sleep, eat, or play
        self.action_space = Discrete(3)
        # array of dog ability to be adopted/happiness
        self.observation_space = Box(low=np.array([0]), high=np.array([100]))
        # start stats
        self.state = random.randint(0, 100)
        self.dog = Dog()
        self.done = False
        self.catRect = pygame.Rect(700, 300, 100, 100)
        self.dogRect = pygame.Rect(100, 300, 100, 100)
        self.cat_health = pygame.Rect(800, 200, 10, 90)
        self.dog_health = pygame.Rect(200, 200, 10, 90)

    def step(self, action):
        # Apply action
        # 0 = sleep
        # 1 = feed
        # 2 = play

        if action == 0 and self.dog.dogSleep < 33:
            self.state += 1
            self.dog.dogSleep += 1
        if action == 1 and self.dog.dogEat < 33:
            self.state += 1
            self.dog.dogEat += 1
        if action == 2 and self.dog.dogPlay < 33:
            self.state += 1
            self.dog.dogPlay += 1

        # Calculate reward
        if self.state == 100:
            reward = 1
        else:
            reward = -1
        # self.state += random.randint(-1,1)
        # Set placeholder for info
        info = {}

        # Return step information
        return self.state, reward, self.done, info

    def render(self, mode='human', **kwargs):
        # Implement viz
        def draw_window(cat, dog, cat_health, dog_health):
            WIN.blit(BACKGROUND, (0, 0))
            WIN.blit(CAT1, (cat.x, cat.y))
            WIN.blit(DOG1, (dog.x, dog.y))
            pygame.draw.rect(WIN, (255, 255, 255), cat_health)
            pygame.draw.rect(WIN, (255, 255, 255), dog_health)
            pygame.display.update()

        draw_window(self.catRect, self.dogRect, self.cat_health, self.dog_health)

    def reset(self):

        self.state = self.dog.dogSleep + self.dog.dogEat + self.dog.dogPlay

        return self.state


def simulate():
    global epsilon, epsilon_decay
    for episode in range(MAX_EPISODES):

        # Init environment
        state = env.reset()
        total_reward = 0

        # AI tries up to MAX_TRY times
        for t in range(MAX_TRY):

            # In the beginning, do random action to learn
            if random.uniform(0, 1) < epsilon:
                action = env.action_space.sample()
            else:
                action = np.argmax(q_table[state])

            # Do action and get result
            next_state, reward, done, _ = env.step(action)
            total_reward += reward

            # Get correspond q value from state, action pair
            q_value = q_table[state][action]
            best_q = np.max(q_table[next_state])

            # Q(state, action) <- (1 - a)Q(state, action) + a(reward + rmaxQ(next state, all actions))
            q_table[state][action] = (1 - learning_rate) * q_value + learning_rate * (reward + gamma * best_q)

            # Set up for the next iteration
            state = next_state

            # Draw games
            env.render()

            # When episode is done, print reward
            if done or t >= MAX_TRY - 1:
                print("Episode %d finished after %i time steps with total reward = %f." % (episode, t, total_reward))
                break

        # exploring rate decay
        if epsilon >= 0.005:
            epsilon *= epsilon_decay


if __name__ == "__main__":
    MAX_EPISODES = 9999
    MAX_TRY = 1000
    epsilon = 1
    epsilon_decay = 0.999
    learning_rate = 0.1
    gamma = 0.6
    gym.envs.registration.register(id='Pygame-v0',
                                   entry_point='main:AnimalEnv',
                                   max_episode_steps=1000)
    env = gym.make("Pygame-v0")
    num_box = tuple((env.observation_space.high + np.ones(env.observation_space.shape)).astype(int))
    q_table = np.zeros(num_box + (env.action_space.n,))
    simulate()

#
# def main():
#     clock = pygame.time.Clock()
#     run = True
#     while run:
#         clock.tick(60)
#         for event in pygame.event.get():
#             if event.type == pygame.QUIT:
#                 run = False
#                 pygame.quit()
#
#         draw_window(cat, dog, cat_health, dog_health)
#     main()
